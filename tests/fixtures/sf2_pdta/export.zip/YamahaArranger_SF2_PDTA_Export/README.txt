YamahaArranger SF2 PDTA Export v1 (read-only audit artifact)

Files
- <font>.pdta.bin            Payload of RIFF LIST 'pdta' (starts with fourcc "pdta", 8-byte LIST+size header excluded).
                             SHA-256 of this file == pdtaSha256 golden (see pdta_manifest.json).
- <font>.names.tsv           phdr/inst/shdr records incl. terminal EOP/EOI/EOS; name_hex_20 = raw 20 name bytes (exact, incl. NUL padding).
- <font>.zones_attenuation.tsv  One row per playable zone (preset global + instrument global zones inherited per SF2 2.01):
                             key/vel range (intersection of preset and instrument ranges), generator 48 at preset and instrument level,
                             raw sum, value clamped to 0..1440 cB, negative flag, sample header fields.
- pdta_manifest.json         Source SF2 name/size/SHA-256, pdta size/SHA-256, golden comparison (MATCH), pdta sub-chunk offsets, counts.

Notes
- Generated from original SF2 bytes (SHA-256 verified against device report), not from text metadata.
- pdta contains only articulation/structure tables and names; no sample audio (sdta) is included.
- Colombo INFO asks not to redistribute its samples; this export contains no sample data. Do not commit the SF2 files themselves.
- Clamp column is the SF2-spec model only; actual BASSMIDI handling of negative/positive attenuation is UNVERIFIED (see U0 calibration probe).
