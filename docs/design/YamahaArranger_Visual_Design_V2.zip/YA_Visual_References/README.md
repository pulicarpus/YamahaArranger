# YamahaArranger — Referensi Visual V2

Status: **referensi desain yang disetujui pengguna**, bukan implementasi atau persetujuan perubahan kode.

## LIVE CONTROL V2
- Referensi gambar: `LIVE_CONTROL_V2.png`
- Nuansa LCD workstation Yamaha PSR-SX / Genos / Tyros.
- Panel STYLE, CHORD, TEMPO, BEAT; INTRO 1–3, ENDING 1–3, MAIN A–D, FILL A–D, START/STOP, ACMP.
- RIGHT1/2/3 dan LEFT dengan pilihan voice, REGISTRATION BANK 1–8, MEMORY, MENU.
- **Tambahkan tombol MIXER** di bagian kanan bawah berdampingan dengan MEMORY dan MENU; navigasi balik ke LIVE tanpa restart style.
- Desain menggambar SUSTAIN, tetapi pada YA harus mengikuti kontrak RELEASE ON/OFF + knob RELEASE yang sudah berlaku; jangan menghidupkan kembali fitur sustain lama tanpa persetujuan.
- SYNC START, BREAK, TAP dan elemen lain hanya diaktifkan setelah API dan perilakunya diverifikasi.

## MIXER V2
- Referensi gambar: `MIXER_V2.png`
- Strip fader vertikal per channel, MUTE, SOLO, PAN, nama voice, MASTER terpisah.
- RIGHT1/2/3, LEFT dan hanya channel style yang dipakai; tidak perlu memaksakan 12 channel jika style menggunakan lebih sedikit.
- Filter channel dan akses DETAIL lewat bagian atas strip/nama voice, tanpa menambah tombol yang membuat penuh.
- Meter harus menunjukkan aktivitas nyata, bukan animasi palsu.
- MIDI OUT E343 tetap dapat dikontrol melalui mixer sesuai jalur MIDI; jangan merusak perbaikan voice otomatis pada connect/reconnect.
- EQ, Effect, Assignable hanya aktif jika fungsinya sudah tersedia dan diverifikasi.

## Batas implementasi
- Prioritas saat ini adalah fungsi REG MEMORY Fase 4 dan pengujian perangkat.
- Jangan menerapkan desain ini ke produksi atau mengubah engine, MIDI router, BASSMIDI, style, RELEASE, dan recall hanya karena referensi visual.
- Rancang UI responsif untuk Redmi Pad landscape, tombol mudah disentuh, dan navigasi tanpa menghentikan style.
