#include "/workspace/YamahaArranger/app/src/main/cpp/voice_resolver.h"
#include <iostream>
#include <sstream>
int main(){std::string l;while(std::getline(std::cin,l)){std::istringstream in(l);std::string file,id,b,p,name;std::getline(in,file,'\t');std::getline(in,id,'\t');std::getline(in,b,'\t');std::getline(in,p,'\t');std::getline(in,name);using namespace voice_resolver;Candidate c{0,file,std::stoi(b),std::stoi(p),name,isYamahaSource(file),isGmSource(file),true};std::cout<<l<<'\t'<<c.yamaha<<'\t'<<familyName(namedFamily(name))<<'\t'<<familyName(c.family())<<'\t'<<familyName(gmFamily(c.program))<<'\n';}}
