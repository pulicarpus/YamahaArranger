# BASSMIDI R1 D0 FULL VALIDATION AND IMPLEMENTATION

**Keputusan: NO-GO. Metadata lengkap, tetapi D0 keselamatan family gagal. Tidak ada patch produksi.**

## Baseline / branch
- SHA lokal dan sumber remote terverifikasi: f4f2c613bebd09a3137bdbe0bc60f0895b597979.
- Branch lokal experiment/bassmidi-r1-resolver sudah tersedia dari checkpoint; working tree bersih.
- Branch sumber, main, desain dan SF2 Master tidak diubah. Tidak ada commit/push/PR/merge R1.

## Validasi ekspor
- Tabel P/PB/I/IB/S/Z seluruh empat font tersedia. TABLES count cocok dengan jumlah record dan expected count pengguna.
- ID P/I/S unik dan lengkap 0..count-1; setiap rentang bag P/I cocok dengan PB/IB; semua referensi Z ke P/PB/I/IB/S valid.
- complete=true, seluruh jumlah relation cocok dengan END, SHA font cocok dengan fixture dan kedua ekspor compact; tidak ditemukan kehilangan tabel.
- Omission lead pada compact bersifat ringkasan diagnostik; analisis memakai seluruh P dan Z dari ZIP, tidak memakai daftar lead parsial.
- Total preset: 1148, instrument: 1211, sample: 10424. Drum memiliki 21 preset terpisah; pool melodic mengikuti produksi (Prime + Colombo + Tyros): 1127 preset, bukan memasukkan font drum sebagai melody.

| Font | Preset | Instrument | Sample | Bytes SF2 asli | SHA SF2 asli, dilaporkan perangkat |
|---|---:|---:|---:|---:|---|
| ColomboGMGS2_BM.sf2 | 892 | 765 | 3288 | 273067684 | `9e4686e4aa7173ffd1baf7ec6f80fcb3fe90880e824cf8c4e1defb5d153d47eb` |
| DRUMKIT YAMAHA PSR-SX700 & SX900 PRIME.sf2 | 21 | 37 | 2257 | 152669056 | `a72158c09677c585eec348762a33da49509bf338c5b36d0e787af58cca0b9f8a` |
| MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2 | 93 | 124 | 2322 | 342996838 | `e8c7356159c200d945f13e113595ff06e7955779b0e9361709d9c7cdba164a82` |
| yamaha tyros 4_just_t4_fixed.sf2 | 142 | 285 | 2557 | 526011878 | `de5b1404630840a2a897e77c6083e2231c5d1523e6571a8afd972a4f684d36ce` |

- Source identity pada header menunjuk file managed /storage/emulated/0/YamahaArranger/SF2; pengguna mengonfirmasi empat file selesai dimuat.
- SHA asli dihitung scanner produksi memakai DigestInputStream, termasuk discard/drain sampai EOF (sdta dan trailing bytes termasuk). Cloud tidak memiliki byte SF2 asli untuk menghitung ulang secara independen; bukti checksum perangkat ditopang implementasi scanner dan fixture historis yang cocok.
- SHA metadata ZIP: `a4ebfaca725ba64874d6e47877ba39920b4c708c9662f8cb77e7545afc71e5dc`.
- SHA compact TXT: `46d4a55f3b4a701cf0f9ea6874fe086c8aee1f87f33a1f81c8ebe7cc61536cff`.
- SHA fixture historis adalah klaim identitas SF2 asli sebelumnya; berbeda konsep dari SHA arsip metadata. Kesamaan nilai digest font saat ini/fixture dibandingkan eksplisit, bukan menyamakan hash ZIP dengan hash SF2.

## Family, collision, source priority
- Family seluruh 1148 P dihitung melalui header resolver produksi tanpa perubahan; full-preset-families.tsv memuat source, P ID, bank, raw PC, nama, Yamaha flag, namedFamily, candidate.family dan gmFamily.
- 158 slot bank/program mempunyai collision lintas source; tidak ditemukan collision di dalam satu file. full-collisions.json mempertahankan setiap identitas sumber, tidak menggabungkan entry.
- 86 kandidat Yamaha bank 0 bernama netral (UNKNOWN) tetap teridentifikasi. 23 kandidat bernama mempunyai family berbeda dari GM PC; bukan otomatis bug, karena nama eksplisit menang dan tidak boleh ditimpa inferensi GM.
- Metadata instrumen dari 86 kandidat diuji memakai namedFamily produksi: terdapat satu konflik instrument-family yang nyata dalam data: Suling S770. Kandidat yang metadata nama instrumennya juga UNKNOWN tidak dianggap telah dibuktikan musikal hanya dari nomor PC.
- Source default dari autoLoadSoundFont/fallbackMelodyScore: melody Prime source0, Colombo source1, Tyros source2; drum terpisah. Pool mengikuti urutan ini serta urutan P. Runtime konfigurasi berbeda membutuhkan perbandingan ulang, tetapi konflik inferensi Suling sendiri tidak bergantung pada anggapan bahwa PC adalah identitas musikal.
- Source0 mendapat +5, Yamaha +20; skor kompatibilitas/exact slot dominan, ties stabil melalui sf2/bank/program/name. SourceYamaha berasal dari predicate nama file; pada audit ini identitas file ditopang checksum ekspor.

## Full-pool A/B (scratch terisolasi)
- A meng-include header produksi aktual. B salinan sementara header hanya V2+V3 di luar repo; namedFamily identik, V1 tidak diterapkan.
- 1280 kasus: bank14 0 dan 112 × PC0..127 × Chord1/Chord2/Phrase2/Pad/nama kosong. 662 pemenang berbeda pada cakupan tersebut, bukan klaim semua bank/semua string request.
- full-pool-baseline-v23.tsv menyimpan winners dan keputusan per kandidat same-PC pada PC3/27/33/48/52/54; full-pool-changed-winners.tsv menyimpan seluruh 662 perubahan.

| Request | Baseline full pool | Scratch V2+V3 |
|---|---|---|
| Chord1, bank14=112, PC=3 | REJECT | MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2|0|3|Yamaha Honky Tonk |
| (empty), bank14=112, PC=3 | REJECT | MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2|0|3|Yamaha Honky Tonk |
| Chord2, bank14=112, PC=27 | REJECT | MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2|0|27|Clean yamaha |
| Chord1, bank14=0, PC=3 | yamaha tyros 4_just_t4_fixed.sf2|0|6|harpsichord | MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2|0|3|Yamaha Honky Tonk |
| Phrase2, bank14=112, PC=33 | yamaha tyros 4_just_t4_fixed.sf2|0|33|FINGER BASS | MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2|0|33|BASS PSR |
| Chord1, bank14=112, PC=48 | yamaha tyros 4_just_t4_fixed.sf2|0|48|t4 strings marcato | MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2|0|48|String Yamaha |
| Pad, bank14=112, PC=54 | yamaha tyros 4_just_t4_fixed.sf2|0|89|woarm pad | yamaha tyros 4_just_t4_fixed.sf2|0|89|woarm pad |
| Chord1, bank14=112, PC=52 | yamaha tyros 4_just_t4_fixed.sf2|0|52|tyros 4 choir | MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2|0|52|Suling S770 |

- Perbedaan dari trace Claude: T4 baseline bank0/PC3 pada full pool memilih Tyros harpsichord PC6, bukan ConcertGrand PC0. Nama request Chord1 tidak mengandung nama piano; full pool mempunyai kandidat Piano Yamaha lain dan stable tie lexicographic. Honky Tonk UNKNOWN ditolak baseline. V3 membukanya pada exact PC3 sehingga pemenang berubah ke Honky Tonk.
- T1/T2/T3, Phrase2 PC33, Chord1 PC48 dan Pad PC54 cocok dengan arah trace subset Claude; tidak berarti seluruh perubahan 662 kasus aman.

## Konflik yang menggagalkan D0
- Prime P id31: bank0, rawPC52/displayPC53, preset Suling S770; namedFamily UNKNOWN.
- PB preset31 bag101 merujuk instrument46 Flute. Seluruh 12 Z eligible; sample Flute-C#4, Flute-D#4, Flute-G4, Flute-A#4 dan lainnya. Ini bukan kandidat choir yang dibuktikan melalui PC.
- gmFamily(52)=CHOIR; namedFamily(Flute)=WOODWIND.
- Baseline Chord1 bank112/PC52: tyros 4 choir. V3 meng-infer Suling sebagai CHOIR, memberi numeric Yamaha slot bonus, lalu source0 +5 membuat Suling menang atas choir Tyros.
- Kontrol negatif named-wrong-family tidak menangkap masalah ini, karena nama PRESET Suling UNKNOWN sementara nama INSTRUMEN Flute baru memperlihatkan pertentangan.
- Maka syarat D0 tidak ada konflik family berisiko yang belum diselesaikan gagal. Status UNKNOWN lain tidak dijadikan bukti aman.

## Tes / implementasi / CI
- Metadata structural/checksum consistency: PASS 4/4.
- T1–T6 pada scratch full-pool: PASS 6/6 target selection; bukan PASS patch produksi.
- N1–N6: PASS 6/6 controlled synthetic policy cases memakai evaluator scratch. Ini bukan klaim semua request negatif terhadap setiap kemungkinan full pool selalu reject.
- Counterexample Suling: reproduced (unsafe acceptance and changed winner). D0 overall: NO-GO.
- Diff produksi: kosong. Tidak ada V1/V2/V3 diterapkan ke repository.
- JVM historis, native recorder, PCM SDK asli, Android compile/ABI dan MIDI recorder A/B untuk R1: NOT RUN, karena STOP D0 sebelum patch produksi. Tidak memakai CI Fase4 sebagai PASS R1.
- MIDI routing, engine, NOTE_ON guard, loader, REG/LIVE, RELEASE, RIGHT OFF, Mixer dan semua source tracked masih byte-identik dengan checkpoint.
- Commit R1: tidak ada. Actions R1: tidak dipicu. APK R1: tidak dibuat.

## Jalur berikutnya membutuhkan keputusan kontrak
- Jangan menerapkan V2+V3 generik sekarang atau menghapus Suling dari inventaris untuk meluluskan gate.
- Opsi review: batasi V3 ke allowlist kandidat yang terverifikasi secara semantik; atau tambah kebijakan identitas nama/metadata yang menolak atau mengklasifikasikan Suling sebagai WOODWIND dan audit ulang seluruh neutral.
- Kedua opsi mengubah kebijakan R1 yang diminta. Belum diimplementasikan dan memerlukan keputusan pemilik; tidak mengubah bassmidi_player.cpp/loader/engine tanpa izin baru.

## Acceptance perangkat setelah kandidat aman tersedia
- ROSITA Main A–D: Chord1/2 accepted binding dan PCM terukur, bukan hanya event MIDI.
- Voice PC3/PC27 serta warna same-PC PC48/PC33 dibandingkan inventaris dan E343.
- E343 tetap normal, connect/reconnect tanpa Bank/PC otomatis.
- REG SAVE/RECALL, LIVE, RELEASE ON/OFF, RIGHT OFF, Mixer dan INTRO/FILL/ENDING tetap berfungsi.
- Catat headroom/clipping tanpa mengganti gain/limiter/FX/drum.
- Seluruh pengujian perangkat UNVERIFIED; tidak ada APK R1 untuk diuji pada tahap NO-GO ini.

**Keputusan akhir: STOP / NO-GO pada gate family D0.**
