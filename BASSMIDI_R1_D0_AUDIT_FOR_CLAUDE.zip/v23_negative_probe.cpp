#include "voice_resolver_v23_probe.h"
#include <cassert>
#include <iostream>
int main(){using namespace r1_probe;
assert(!evaluate(Request{8*128+112,3,""},Candidate{0,"Yamaha.sf2",8,3,"Neutral",true,false,true}).accepted);
assert(!evaluate(Request{112,3,"Chord1"},Candidate{1,"Colombo.sf2",8,3,"Neutral",false,true,true}).accepted);
assert(!evaluate(Request{112,3,"Chord1"},Candidate{0,"Yamaha.sf2",0,4,"Neutral",true,false,true}).accepted);
assert(!evaluate(Request{112,3,"Chord1"},Candidate{0,"Yamaha.sf2",0,3,"Guitar",true,false,true}).accepted);
assert(!evaluate(Request{112,3,"Chord1"},Candidate{1,"foreign.sf2",0,3,"Neutral",false,false,true}).accepted);
assert(!evaluate(Request{104*128,3,""},Candidate{0,"Yamaha.sf2",104,3,"Neutral",true,false,true}).accepted);
std::cout<<"N1-N6 synthetic policy controls 6/6 PASS; musical compatibility not established\n";
assert(evaluate(Request{112,52,"Chord1"},Candidate{0,"MELODI YAMAHA PSR-SX700 & SX900 PRIME.sf2",0,52,"Suling S770",true,false,true}).accepted);
std::cout<<"Counterexample: V3 accepts Suling S770 as CHOIR despite Flute metadata; D0 semantic NO-GO\n";}
